<?php
	/* ************************************************** */
	// GLOBALS
	/* ************************************************** */
	if (!function_exists('pmm_add_scripts2')) {
		define('PMM_FILE_PATH2',   trailingslashit(dirname(__FILE__ )));
		define('PMM_FILE_URL2' ,   str_replace('\\', '/', _GPI_PLUGIN_URL . 'post-meta-manager-api/'));
		// define('PMM_FILE_URL2' ,   str_replace('\\', '/', trailingslashit(plugins_url('', __FILE__))));
		define('PMM_FIELDS_PATH2', PMM_FILE_PATH2 . 'fields/');
		define('PMM_IMAGES_URL2',  PMM_FILE_URL2 . 'images/');

		require_once(PMM_FILE_PATH2 . 'PostMetaManager.class.php');
		
		// require_once('tmp/cpt.php');
		
		function pmm_add_scripts2() {
			wp_enqueue_script('jquery-ui-core');
			wp_enqueue_script('jquery-ui-tabs');	
			wp_enqueue_script('jquery-ui-button');
			wp_enqueue_script('jquery-ui-sortable');
			wp_enqueue_script('jquery-ui-datepicker');
			
			if (function_exists('wp_enqueue_media')) {
				if (isset($_GET['taxonomy']) && !empty($_GET['taxonomy'])) {
					if ($_GET['taxonomy'] == 'csoftware'
					|| $_GET['taxonomy'] == 'category'
					|| $_GET['taxonomy'] == 'genre'
					|| $_GET['taxonomy'] == 'synth'
					|| $_GET['taxonomy'] == 'software-fx'
					|| $_GET['taxonomy'] == 'software-synth'
					|| $_GET['taxonomy'] == 'software-developer'
					|| $_GET['taxonomy'] == 'software-platform'
					|| $_GET['taxonomy'] == 'shop_vendor') {
						wp_enqueue_media();
					}
				}
			} else {
				wp_enqueue_style('thickbox');
				wp_enqueue_script('media-upload');
				wp_enqueue_script('thickbox');
			}
			wp_enqueue_script('json2');
			
			wp_enqueue_script('jquery-nested-sortable', PMM_FILE_URL2 . 'libs/nestedSortable/jquery.nestable.js', array('jquery-ui-sortable'));
			wp_enqueue_style('jquery-nested-sortable', PMM_FILE_URL2 . 'libs/nestedSortable/style.css');
			wp_enqueue_script('pmm', PMM_FILE_URL2 . 'libs/pmm.js', array('jquery'));
			// wp_enqueue_style('jquery-ui', (is_ssl() ? 'https' : 'http') . '://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css');
			wp_enqueue_style('jquery-ui', PMM_FILE_URL2 . 'css/jquery-ui-1.10.4.custom.min.css');
			
			wp_enqueue_script('wp-color-picker');
			wp_enqueue_style('wp-color-picker');
		}
		
		add_action('admin_enqueue_scripts', 'pmm_add_scripts2');
	}
?>