<?php
	global $chk_key_count;
	if (empty($chk_key_count)) $chk_key_count = 0;
	$chk_key_count++;
	// var_dump($saved_value);
?>
<input
	type="checkbox"
	id="dummy_<?php _e($field_data['key']) ?>_<?php echo($chk_key_count) ?>"
	name=""
	value="<?php _e($saved_value == PostMetaManagerHelper2::CheckboxChecked ? PostMetaManagerHelper2::CheckboxChecked : PostMetaManagerHelper2::CheckboxUnchecked) ?>"
	<?php _e($saved_value == PostMetaManagerHelper2::CheckboxChecked ? 'checked="checked"' : '') ?> 
/>
<input
	type="checkbox"
	id="<?php _e($field_data['key']) ?>_<?php echo($chk_key_count) ?>"
	name="<?php _e($identifier) ?>"
	value="<?php _e($saved_value == PostMetaManagerHelper2::CheckboxChecked ? PostMetaManagerHelper2::CheckboxChecked : PostMetaManagerHelper2::CheckboxUnchecked) ?>"
	<?php _e($saved_value == PostMetaManagerHelper2::CheckboxChecked ? 'checked="checked"' : '') ?> 
	style="display: none;"
/>
<?php if (isset($label) && !empty($label)) { ?>
	&nbsp;&nbsp;&nbsp;<label for="dummy_<?php _e($field_data['key']) ?>_<?php echo($chk_key_count) ?>"><?php _e($label) ?></label>
<?php } ?>
<script type="text/javascript">
	jQuery(function ($)
	{
		var $checkbox = $("#<?php _e($field_data['key']) ?>_<?php echo($chk_key_count) ?>");
		var $dummyCheckbox = $("#dummy_<?php _e($field_data['key']) ?>_<?php echo($chk_key_count) ?>");
		$dummyCheckbox.change(function ()
		{
			var $this = $(this);
			if ($this.is(":checked"))
			{
				$checkbox.val("<?php _e(PostMetaManagerHelper2::CheckboxChecked) ?>");
				$checkbox.attr("checked", "checked");
			}
			else
			{
				$checkbox.val("<?php _e(PostMetaManagerHelper2::CheckboxUnchecked) ?>");
				$checkbox.attr("checked", "checked");
			}
		});
	});
</script>