<?php
	/* ***************************************************** */
	// FUNCTIONS
	/* ***************************************************** */	
	function print_color_variation_content_boxes($overview_items, $type) {
		if ($overview_items && isset($overview_items)) {
			$box_content_all = html_entity_decode($overview_items);
			$box_content_all = stripslashes($box_content_all);
			$box_content_all = json_decode($box_content_all);
			// var_dump($box_content_all);die();
			foreach ($box_content_all as $box_content) {
				$att_id = $box_content->image;
				$attachment = null;
				if (is_numeric($att_id) && $att_id > 0) {
					$attachment = get_post($att_id);
				}
				?>
					<li class='sortableItem ui-state-default SORTABLE_ITEM <?php _e($type) ?>' data-type="<?php _e($type) ?>">
						<a href='#' class='remove REMOVE_ITEM' title='Remove Item'></a>
						<div class='imageFieldWrp'><a href='#' class='button ADD_IMAGE'>Add Image</a><a href='#' class='button REMOVE_IMAGE'>Remove Image</a><br/><img src='<?php _e($attachment ? $attachment->guid : '') ?>' alt='' <?php _e($attachment ? '' : 'style="display: none;"') ?>' /><input type='hidden' class='imageField' value='<?php _e($attachment ? $attachment->ID : '') ?>' /></div>
						<div class='titleFieldWrp'>Color:<select type='text' class='colorField' value='' multiple='multiple'></select></div>
						<div class='hidden contentFieldWrp'>Color ID:<input type='text' class='colorIDField' value='<?php _e($box_content->color_id) ?>' /></div>
						<div class='pantoneFieldWrp'>Pantone #:<input type='text' class='pantoneField' value='<?php _e($box_content->pantone) ?>' /></div>
						<div class='contentFieldWrp'>Featured:&nbsp;<input type='checkbox' class='colorFeatured' value='' <?php _e($box_content->featured == 1 ? 'checked="checked"' : '') ?> /></div>
					</li>																
				<?php
			}
		}	
	}

	function print_color_variation_box_wrp($overview_items, $identifier, $title) {
		?>
			<table class="form-table">
				<tbody>
					<!--
					<tr class="topFeaturedBoxes" data-classname="<?php _e($identifier) ?>">
						<th scope="row"><label for="<?php _e($identifier) ?>"><?php _e($title) ?></label></th>
					</tr>
					-->
					<tr>
						<td>
							<div class="featuredBoxWrp">
								<input type="hidden" name="<?php _e($identifier) ?>" class="HIDDEN_FIELD_ROOT" value='' />
								<input type="button" value="Add new item" class="button ADD_NEW_ITEM" />
								<ul class="sortableItemWrp SORTABLE_ITEM_WRP">
									<?php print_color_variation_content_boxes($overview_items, $identifier); ?>
								</ul>
							</div>
						</td>
					</tr>
				</tbody>
			</table>
		<?php
	}	
	
	function render_color_variation_metabox_overview_fields($overview_items, $identifier, $wrap_id) {
		global $post;
		// var_dump($overview_items);die();
		if (is_array($overview_items) && count($overview_items) > 0) $overview_items = $overview_items[0];
		?>
			<div id='loadingOverlay'>
				<?php
					$args = array(
						'raw'           => true,
						'media_buttons' => false,
						'teeny'         => true,
						'tinymce'       => true
					);
					
					// wp_editor(
						// '',
						// 'DUMMY_EDITOR',
						// $args
					// );					
				?>
				<p class="submit">
					<input type="button" class="button button-primary INSERT_HTML" value="Save Changes">
					&nbsp;|&nbsp;
					<input type="button" class="button button-primary CANCEL_HTML" value="Cancel">
				</p>
			</div>
			<div class="wrap-<?php _e($wrap_id) ?>">
				<div class="filter">
					Filter: <select id="filterColorVariation"><option class="showAll" value="all">Show All</option><option class="featured" value="featured">Show Featured</option></select>
				</div>
				<?php print_color_variation_box_wrp($overview_items, $identifier, '') ?>
				<style type="text/css">
					.wrap-<?php _e($wrap_id) ?> .sortableItem { cursor: move; }
					.wrap-<?php _e($wrap_id) ?> .sortableItem, .wrap-<?php _e($wrap_id) ?> .ui-state-highlight { width: 300px; height: 455px; margin: 20px 5px; position: relative; float: left; }
					.wrap-<?php _e($wrap_id) ?> .sortableItem > div { min-height: 100px; width: 96%; margin-left: 2%; }
					.wrap-<?php _e($wrap_id) ?> .sortableItem input[type=text], .wrap-<?php _e($wrap_id) ?> .sortableItem textarea { width: 100%; margin: 0 auto; resize: none; }
					.wrap-<?php _e($wrap_id) ?> .titleFieldWrp > select { width: 90%; margin: 0 auto; display: block; height: 200px; }
					.wrap-<?php _e($wrap_id) ?> .imageFieldWrp img { max-width: 150px; max-height: 150px; margin-top: 15px; }
					.wrap-<?php _e($wrap_id) ?> .sortableItem > .remove { width: 24px; height: 24px; background: url('<?php _e(PMM_IMAGES_URL2) ?>icons.png') no-repeat; background-position: -24px 0; position: absolute; top: -12px; right: -12px; display: none; }
					.wrap-<?php _e($wrap_id) ?> .sortableItem.HOVER > .remove { display: block; }
					.wrap-<?php _e($wrap_id) ?> .sortableItem > .editHTML { width: 24px; height: 24px; background: url('<?php _e(PMM_IMAGES_URL2) ?>icons.png') no-repeat; background-position: 0 0; position: absolute; top: 77px; right: -3px; display: none; }
					.wrap-<?php _e($wrap_id) ?> .sortableItem.HOVER > .editHTML { display: block; }
					.wrap-<?php _e($wrap_id) ?> .sortableItem > .imageFieldWrp { text-align: center; padding-top: 10px; }
					.wrap-<?php _e($wrap_id) ?> .sortableItem > .imageFieldWrp .REMOVE_IMAGE { display: none; }
					.wrap-<?php _e($wrap_id) ?> .contentFieldWrp { margin-top: 10px; }
					.wrap-<?php _e($wrap_id) ?> .pantoneFieldWrp { margin-top: 10px; min-height: 0 !important; }
					
					.wrap-<?php _e($wrap_id) ?> .slider { height: 140px; }
					.wrap-<?php _e($wrap_id) ?> .slider .titleFieldWrp { display: none; }
					
					.wrap-<?php _e($wrap_id) ?> .most_popular { height: 140px; }
					.wrap-<?php _e($wrap_id) ?> .most_popular .imageFieldWrp { display: none; }

					.wrap-<?php _e($wrap_id) ?> .business_directory { height: 140px; }
					.wrap-<?php _e($wrap_id) ?> .business_directory .imageFieldWrp { display: none; }	

					.dummyImageContainer-<?php _e($wrap_id) ?> { position: absolute; max-width: 300px; max-height: 300px; padding: 5px; background-color: #ffffff; border: 1px solid black; display: none; }
					
					.wrap-<?php _e($wrap_id) ?> .typeFieldWrp input[type=checkbox] { margin-right: 5px; }
					.wrap-<?php _e($wrap_id) ?> .typeFieldWrp { display: none; }
					
					#loadingOverlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: url(<?php _e(PMM_IMAGES_URL2) ?>bgOpacityBlack25.png) repeat; z-index: 9999; display: none; }					
					#loadingOverlay .submit { position: relative; text-align: right; margin-right: 10% !important; top: 120px; }
					#wp-DUMMY_EDITOR-wrap { margin: 0 auto; width: 80% !important; position: relative !important; top: 100px !important; }
				</style>
				<script type="text/javascript">
					WAIT_FOR_ATTACHMENT_INSERT = false;
					$loadingScreen = null;
					$clickedContainerRoot = null;
					ACTIVE_COLORS = [];
					DOING_CHECKBOX_WORK = false;
					jQuery(function ($)
					{
						$loadingScreen = $("#loadingOverlay");
						$("body").append($loadingScreen);
						var $filterColorVariation = $(".wrap-<?php _e($wrap_id) ?> #filterColorVariation");
				
						var reSetColors = function ()
						{
							var values = [];
							$("#hat_colorchecklist input[type=checkbox]:checked:not([disabled])").each(function ()
							{
								var $this = $(this);
								if ($this.parents(".children").length > 0)
								{
									var name = $.trim($this.parents("ul").first().parent().find(" > .selectit").text()) + " > " + $.trim($this.parent().text())
									values.push({ value: this.value, name: name });
								}
							});
							ACTIVE_COLORS = values;
							
							$(".wrap-<?php _e($wrap_id) ?> select.colorField").each(function ()
							{
								var $this = $(this);
								var oldVal = $this.val();
								$this.find("*").remove();
								$.each(ACTIVE_COLORS, function ()
								{
									var selected = "";
									if ($.inArray(this.value, oldVal) !== -1) selected = "selected='selected'";
									$this.append("<option value='" + this.value + "' " + selected + ">" + this.name + "</option>");
								});
							});
							
							var oldFilterVal = $filterColorVariation.val();
							$filterColorVariation.find("*:not(.showAll):not(.featured)").remove();
							$filterColorVariation.unbind("change");
							$.each(ACTIVE_COLORS, function ()
							{
								var selected = "";
								if (this.value == oldFilterVal) selected = "selected='selected'";
								$filterColorVariation.append("<option value='" + this.value + "' " + selected + ">Show " + this.name + "</option>");
							});
							$filterColorVariation.change(filterColorVariationFn);
						};
						// reSetColors();
						$("#hat_colorchecklist input[type=checkbox]").change(function ()
						{
							reSetColors();
							$(".wrap-<?php _e($wrap_id) ?> .colorIDField").each(function ()
							{
								var $that = $(this);
								var $root = $that.parents(".SORTABLE_ITEM").first();
								var val = $that.val();
								var remove = [];
								if (val.length > 0)
								{
									var values = val.split(",");
									$.each(values, function ()
									{
										var val = this + "";
										$root.find("select.colorField option").each(function ()
										{
											var $this = $(this);
											var found = $root.find("select.colorField option[value=" + val + "]").length > 0;
											if (found)
											{
												// if ($.inArray(val, values) !== -1) $this.attr("selected", "selected");
											}
											else
											{
												remove.push(val);									
											}
										});
									});
									$.each(remove, function ()
									{
										var val = this + "";
										if ($.inArray(val, values) !== -1)
										{
										values.splice($.inArray(val, values), 1);
										$that.val( values.join(",") );	
										}
									});
								}
								else
								{
									$that.val("");
								}
							});
							refreshItems<?php _e($wrap_id) ?>();
						});

						$(".wrap-<?php _e($wrap_id) ?> select.colorField").live("change", function ()
						{
							var $this = $(this);
							var val = $this.val();
							if (val.length > 0)
								$this.parents(".SORTABLE_ITEM").first().find(".colorIDField").val( val.join(",") );
							else
								$this.parents(".SORTABLE_ITEM").first().find(".colorIDField").val("");
							$filterColorVariation.trigger("change");
						});
				
						/* ***************************************************** */
						// FEATURED BOX MANAGEMENT LOGIC
						/* ***************************************************** */						
						var refreshItems<?php _e($wrap_id) ?> = function ()
						{
							reSetColors();
							$(".wrap-<?php _e($wrap_id) ?> .featuredBoxWrp").each(function ()
							{
								var $this = $(this);
								var data  = [];
								$this.find(".SORTABLE_ITEM_WRP > .SORTABLE_ITEM").each(function ()
								{
									var $that = $this;
									var $this = $(this);
									data.push({
										image:         $this.find(".imageField").val(),
										// color:           $this.find(".colorField").val().replace(/'/g, "&#39;").replace(/"/g, '&#34;'),
										pantone:       $this.find(".pantoneField").val().replace(/'/g, "&#39;").replace(/"/g, '&#34;'),
										color_id:      $this.find(".colorIDField").val().replace(/'/g, "&#39;").replace(/"/g, '&#34;'),
										featured:      $this.find(".colorFeatured").is(":checked") ? 1 : 0
									});
								});
								data = JSON.stringify(data);
								// console.log(data);
								$this.find(".HIDDEN_FIELD_ROOT").val(data);
							});
						}
						if (typeof REFRESH_BEFORE_POST === "function") REFRESH_BEFORE_POST.push(refreshItems<?php _e($wrap_id) ?>);
						// setTimeout(refreshItems<?php _e($wrap_id) ?>, 100);
						refreshItems<?php _e($wrap_id) ?>();
						
						
						function checkboxChange ()
						{
							if (DOING_CHECKBOX_WORK) return;
							DOING_CHECKBOX_WORK = true;
							var $this = $(this);
							var checked = $this.is(":checked");
							$(".wrap-<?php _e($wrap_id) ?> .colorFeatured").removeAttr("checked");
							/* if (checked)  */$this.attr("checked", "checked");
							$filterColorVariation.trigger("change");
							DOING_CHECKBOX_WORK = false;
						};
						$(".wrap-<?php _e($wrap_id) ?> .colorFeatured").live("change", checkboxChange);
						
						$(".wrap-<?php _e($wrap_id) ?> .colorField, " +
							".wrap-<?php _e($wrap_id) ?> .colorFeatured, " +
							".wrap-<?php _e($wrap_id) ?> .pantoneField, " +
							".wrap-<?php _e($wrap_id) ?> .colorIDField").live("change", refreshItems<?php _e($wrap_id) ?>);
						
						var imageMediaPopup = wp.media({
							title : 'Pick an image to attach to this item',
							multiple : false,
							library : { type : 'image'},
							button : { text : 'Insert' }
						});
					
						function makeItemsSortable ()
						{
							$(".wrap-<?php _e($wrap_id) ?> .SORTABLE_ITEM_WRP").sortable({
								placeholder: "ui-state-highlight",
								containment: "body",
								start: function (e, ui)
								{
									$(".wrap-<?php _e($wrap_id) ?> .ui-state-highlight").attr("class", "ui-state-highlight " + ui.item.data("type"));
								},
								stop: refreshItems<?php _e($wrap_id) ?>
							})
							
							$(".wrap-<?php _e($wrap_id) ?> .SORTABLE_ITEM").unbind('mouseenter mouseleave').hover(
								function () { $(this).addClass("HOVER"); },
								function () { $(this).removeClass("HOVER"); }
							);
						}
						makeItemsSortable();
						
						function addNewItem ($el)
						{
							var classname = $el.parents("tr").first().data("classname");
							var html = "<li class='sortableItem ui-state-default SORTABLE_ITEM " + classname + "' data-type='" + classname + "'>";
							html += "<a href='#' class='remove REMOVE_ITEM' title='Remove Item'></a>";
							html += "<div class='imageFieldWrp'><a href='#' class='button ADD_IMAGE'>Add Image</a><a href='#' class='button REMOVE_IMAGE'>Remove Image</a><br/><img src='' alt='' style='display: none;' /><input type='hidden' class='imageField' value='' /></div>";
							html += "<div class='titleFieldWrp'>Color:<select type='text' class='colorField' value='' multiple='multiple'></select></div>";
							html += "<div class='hidden contentFieldWrp'>Color ID:<input type='text' class='colorIDField' value='' /></div>";
							html += "<div class='pantoneFieldWrp'>Pantone #:<input type='text' class='pantoneField' value='' /></div>";
							html += "<div class='contentFieldWrp'>Featured:&nbsp;<input type='checkbox' class='colorFeatured' value='' /></div>";
							html += "</li>";
							$el.parents("tr").first().find(".SORTABLE_ITEM_WRP").append(html);
							makeItemsSortable();
							refreshItems<?php _e($wrap_id) ?>();
							if ($(".wrap-<?php _e($wrap_id) ?> .SORTABLE_ITEM").length == 1)
							{
								$(".wrap-<?php _e($wrap_id) ?> .SORTABLE_ITEM .colorFeatured").attr("checked", "checked");
							}
						}
						
						$(".wrap-<?php _e($wrap_id) ?> .ADD_NEW_ITEM").click(function (e)
						{
							e.preventDefault();
							var $this = $(this);
							var classname = $this.parents("tr").first().data("classname");
							if (classname == "top_featured_boxes")
							{
								if ($this.parents("tr").find(".SORTABLE_ITEM").length < 4) addNewItem($this); 
							}
							else
							{
								addNewItem($this); 
							}
						});
						
						$(".wrap-<?php _e($wrap_id) ?> .REMOVE_ITEM").live("click", function (e)
						{
							e.preventDefault();
							var wasChecked = $(this).parent().find(".colorFeatured").is(":checked");
							$(this).parent().remove();
							refreshItems<?php _e($wrap_id) ?>();
							if (wasChecked)
							{
								$(".wrap-<?php _e($wrap_id) ?> .SORTABLE_ITEM").last().find(".colorFeatured").attr("checked", "checked");
							}
						});

						$(".wrap-<?php _e($wrap_id) ?> .ADD_IMAGE").live("click", function (e)
						{
							e.preventDefault();
							$(this).addClass("ATT_SELECTED");
							imageMediaPopup.open();
						});
						
						$(".wrap-<?php _e($wrap_id) ?> .REMOVE_IMAGE").live("click", function (e)
						{
							e.preventDefault();
							var $this = $(this);
							$this.parent().find(".imageField").val("");
							$this.parent().find("img").hide(0);
							refreshItems<?php _e($wrap_id) ?>();
						});							
						
						/* ***************************************************** */
						// MEDIA POPUP EVENTS
						/* ***************************************************** */	
						function mediaUploaderOpen (frame) 
						{
							var selection    = frame.state().get('selection');
							var $selected    = $(".ATT_SELECTED");
							var attachmentID = Number($selected.parent().find(".imageField").val());
							if (typeof attachmentID === "number" && attachmentID > 0)
							{
								var attachment = wp.media.attachment(attachmentID);
								attachment.fetch();
								selection.add(attachment ? [attachment] : []);
							}
							else
							{
								selection.add([]);
							}
						}
						
						function mediaUploaderClose ()
						{
							WAIT_FOR_ATTACHMENT_INSERT = true;
							setTimeout(function ()
							{
								if (WAIT_FOR_ATTACHMENT_INSERT)
								{
									$(".ATT_SELECTED").removeClass("ATT_SELECTED");
									WAIT_FOR_ATTACHMENT_INSERT = false;
								}
							}, 200);
						}

						function mediaUploaderSelect (frame)
						{
							WAIT_FOR_ATTACHMENT_INSERT = false;
							var $selected = $(".ATT_SELECTED");
							if ($selected.length > 0)
							{
								var selection = frame.state().get('selection');
								if (selection.length > 0)
								{
									selection.each(function (attachment)
									{
										$selected.parent().find(".imageField").val(attachment.id);
										$selected.parent().find("img").attr("src", attachment.collection._byId[attachment.id].attributes.url).show(0);
									});								
								}
								else
								{
									$selected.parent().find(".imageField").val("");
									$selected.parent().find("img").hide(0);
								}
							}
							$selected.removeClass("ATT_SELECTED");
							refreshItems<?php _e($wrap_id) ?>();
						}							
						
						/* BIND IMAGE MEDIA POPUP EVENTS */
						imageMediaPopup.on("open", function () { mediaUploaderOpen(imageMediaPopup); });
						imageMediaPopup.on("close", function () { mediaUploaderClose() });	
						imageMediaPopup.on("select", function () { mediaUploaderSelect(imageMediaPopup); });
						
						/* ADD IMAGE HOVER LOGIC */
						var $dummyImageContainer = $("<img src='' alt='' class='dummyImageContainer-<?php _e($wrap_id) ?>' />");
						$dummyImageContainer.fadeOut(0);
						$("body").append($dummyImageContainer);
						$(".wrap-<?php _e($wrap_id) ?> .imageFieldWrp img").live("mouseenter", function ()
						{
							$dummyImageContainer.attr("src", $(this).attr("src"));
							$dummyImageContainer.fadeIn("fast");
							// console.log($dummyImageContainer);
						}).live("mouseleave", function ()
						{
							$dummyImageContainer.fadeOut("fast");
						}).live("mousemove", function (e)
						{
							$dummyImageContainer.css({
								left: e.pageX + 5,
								top:  e.pageY + 5
							});
						});
						
						/* ITEM TYPE CHECKBOX CHANGE */
						var checkboxChange = function ()
						{
							var $that   = $(this);
							var $parent = $that.parent();
							$(".wrap-<?php _e($wrap_id) ?> .typeFieldWrp input[type=checkbox]").die("change");
							$parent.find("input[type=checkbox]").each(function ()
							{
								var $this = $(this);
								if ($this.get(0) != $that.get(0))
								{
									$this.removeAttr("checked");
								}
							});							
							$(".wrap-<?php _e($wrap_id) ?> .typeFieldWrp input[type=checkbox]").live("change", checkboxChange);
						};
						$(".wrap-<?php _e($wrap_id) ?> .typeFieldWrp input[type=checkbox]").live("change", checkboxChange);
						
						/* EDIT HTML BUTTON LOGIC */
						$(".EDIT_HTML").live("click", function (e)
						{
							e.preventDefault();
							if (typeof $loadingScreen === "object") $loadingScreen.fadeIn("fast");
							$clickedContainerRoot = $(this).parent();
							tinyMCE.get("DUMMY_EDITOR").setContent($clickedContainerRoot.find(".contentField").val());
						});
						$(".INSERT_HTML").live("click", function (e)
						{
							e.preventDefault();
							var content = tinyMCE.get("DUMMY_EDITOR").getContent();
							var realContent = "";
							$("<div>" + content + "</div>").find("p").each(function ()
							{
								realContent += $(this).html();
							});
							// console.log(realContent);
							$clickedContainerRoot.find(".contentField").val(realContent);
							if (typeof $loadingScreen === "object") $loadingScreen.fadeOut("fast");
							$clickedContainerRoot = null;
							$(".htmlListWrp.HTML_LIST_WRP.overview_features").find(".HTML_LIST_ITEM.overview_features input[type=text]").change();
						});
						$(".CANCEL_HTML").live("click", function (e)
						{
							e.preventDefault();
							if (typeof $loadingScreen === "object") $loadingScreen.fadeOut("fast");
							$clickedContainerRoot = null;
						});
						
						$(".wrap-<?php _e($wrap_id) ?> .colorIDField").each(function ()
						{
							var $this = $(this);
							var $root = $this.parents(".SORTABLE_ITEM").first();
							var val = $this.val();
							if (val.length > 0)
							{
								var values = val.split(",");
								$root.find("select.colorField option").each(function ()
								{
									var $this = $(this);
									if ($.inArray($this.val(), values) !== -1) $this.attr("selected", "selected");
								});
							}
							else
							{
								$root.find("select.colorField").val("");
							}
						});
						
						var filterColorVariationFn = function ()
						{
							var $this = $(this);
							var rootVal = $this.val();
							if (rootVal == "all")
							{
								$(".SORTABLE_ITEM").show("fast");
							}
							else if (rootVal == "featured")
							{
								$(".SORTABLE_ITEM").hide("fast");
								$(".SORTABLE_ITEM .colorFeatured:checked").parents(".SORTABLE_ITEM").first().show("fast");
							}
							else
							{
								$(".SORTABLE_ITEM").each(function ()
								{
									var $this = $(this);
									var val = $this.find(".colorIDField").val();
									if (val.length > 0)
									{
										var values = val.split(",");
										if ($.inArray(rootVal, values) !== -1)
										{
											$this.addClass("REMAIN_SHOWN");
										}
									}
									else
									{
										$this.addClass("REMAIN_SHOWN");
									}
								});
								$(".SORTABLE_ITEM:not(.REMAIN_SHOWN)").hide("fast");
								$(".SORTABLE_ITEM.REMAIN_SHOWN").show("fast", function ()
								{
									$(".SORTABLE_ITEM").removeClass("REMAIN_SHOWN");
								});
							}
						}						
						$filterColorVariation.change(filterColorVariationFn);
					});
				</script>
			</div>
		<?php
	}
	
	global $wrap_id;
	if ($wrap_id == null) $wrap_id = 0;
	render_color_variation_metabox_overview_fields($saved_value, $identifier, ++$wrap_id);
?>