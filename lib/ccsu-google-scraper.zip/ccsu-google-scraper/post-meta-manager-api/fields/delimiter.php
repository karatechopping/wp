<tr>
	<td colspan="2" class="delimiter">
		<br />
		<hr />
		<br />
	</td>
</tr>